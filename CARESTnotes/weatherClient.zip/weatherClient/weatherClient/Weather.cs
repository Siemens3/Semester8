﻿



namespace WeatherClient
{
 
    public class Weather
    {
        public string City { get; set; }
        public bool WeatherWarning { get; set; }
       
        public double Temp { get; set; }
       
        public double WindSpeed { get; set; }
        public string Condition { get; set; }

       
    }
}
